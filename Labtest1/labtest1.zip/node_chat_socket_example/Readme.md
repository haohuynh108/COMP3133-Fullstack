https://www.freecodecamp.org/news/simple-chat-application-in-node-js-using-express-mongoose-and-socket-io-ee62d94f5804/
https://github.com/amkurian/simple-chat

https://socket.io/docs/v3/emit-cheatsheet/


https://stackabuse.com/node-js-websocket-examples-with-socket-io/

https://www.geeksforgeeks.org/web-socket-in-nodejs/

https://tsh.io/blog/socket-io-tutorial-real-time-communication/


https://medium.com/@noufel.gouirhate/build-a-simple-chat-app-with-node-js-and-socket-io-ea716c093088